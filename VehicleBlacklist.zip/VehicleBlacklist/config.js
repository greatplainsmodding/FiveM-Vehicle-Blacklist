module.exports = {
    url: "http://localhost:5000/api/fetch"
}